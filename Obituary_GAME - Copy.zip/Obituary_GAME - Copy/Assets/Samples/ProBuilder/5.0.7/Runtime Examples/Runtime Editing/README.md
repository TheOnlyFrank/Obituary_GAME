# Important

By default, ProBuilder scripts are removed during the build process. To enable runtime editing in Standalone builds:

- Open the **Preferences** window
- Select the **ProBuilder** category
- Under **General**, un-check **Script Stripping**